﻿using System.Windows.Controls;

namespace SnakeGame
{
    /// <summary>
    /// Interaction logic for GameInfo.xaml
    /// </summary>
    public partial class GameInfo : Page
    {
        public GameInfo()
        {
            InitializeComponent();
        }
    }
}
