﻿namespace MemoryGame
{
    internal class MemoryCardClass
    {
        string CardNameId
        {
            get;
            set;
        }


        string FrontMemoryCardImage
        {
            get;
            set;
        }

        string BackMemoryCardImage
        {
            get;
            set;
        }

    }
}
